# Kenya Life Online 🇰🇪

A real multiplayer-ready Kenyan life simulator starter.

## What is included
- Account registration/login
- Secure password hashing
- Persistent SQLite database
- Individual player money, energy, XP, level, business and home
- Jobs, rest, food, matatu, business and random events
- Live leaderboard via Socket.IO
- Mobile-friendly browser UI

## Run it
Install Node.js 18+.

```bash
npm install
npm start
```

Then open `http://localhost:3000`.

## Deploy
Deploy this Node app to a Node-compatible host (for example Render, Railway, Fly.io or a VPS). Set:
- `SESSION_SECRET` to a long random secret
- `PORT` if your host requires it

For production, use a persistent disk/database rather than ephemeral storage if your host does not persist `kenya-life.db`.

## Important
The money in the game is virtual. This starter does not connect to M-Pesa or handle real-money transactions.
