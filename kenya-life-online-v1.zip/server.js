const express=require("express");
const http=require("http");
const path=require("path");
const session=require("express-session");
const bcrypt=require("bcryptjs");
const Database=require("better-sqlite3");
const {Server}=require("socket.io");

const app=express(), server=http.createServer(app), io=new Server(server);
const db=new Database("kenya-life.db");
db.pragma("journal_mode=WAL");
db.exec(`
CREATE TABLE IF NOT EXISTS users(
 id INTEGER PRIMARY KEY AUTOINCREMENT,
 username TEXT UNIQUE NOT NULL,
 password_hash TEXT NOT NULL,
 city TEXT NOT NULL DEFAULT 'Nairobi',
 money INTEGER NOT NULL DEFAULT 500,
 energy INTEGER NOT NULL DEFAULT 100,
 xp INTEGER NOT NULL DEFAULT 0,
 level INTEGER NOT NULL DEFAULT 1,
 business TEXT NOT NULL DEFAULT '',
 home_level INTEGER NOT NULL DEFAULT 1,
 assets INTEGER NOT NULL DEFAULT 0,
 created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS events(
 id INTEGER PRIMARY KEY AUTOINCREMENT,
 user_id INTEGER NOT NULL,
 message TEXT NOT NULL,
 created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);`);

app.use(express.json());
app.use(express.urlencoded({extended:true}));
app.use(express.static(path.join(__dirname,"public")));
app.use(session({
 secret:process.env.SESSION_SECRET||"change-this-secret-in-production",
 resave:false, saveUninitialized:false,
 cookie:{httpOnly:true,sameSite:"lax",secure:false,maxAge:7*24*60*60*1000}
}));

function user(req){return req.session.userId ? db.prepare("SELECT * FROM users WHERE id=?").get(req.session.userId):null}
function safe(u){if(!u)return null; const {password_hash,...x}=u; return x}
function event(uid,message){db.prepare("INSERT INTO events(user_id,message) VALUES(?,?)").run(uid,message)}
function auth(req,res,next){const u=user(req); if(!u)return res.status(401).json({error:"Please log in."}); req.user=u; next()}
function refreshLevel(u){
  let xp=u.xp, level=u.level;
  while(xp>=level*100){xp-=level*100;level++}
  db.prepare("UPDATE users SET xp=?,level=? WHERE id=?").run(xp,level,u.id);
}
function broadcast(){io.emit("leaderboard",leaderboard())}
function leaderboard(){
 return db.prepare("SELECT username,city,money,level,business FROM users ORDER BY money+assets DESC LIMIT 20").all()
}

app.post("/api/register",(req,res)=>{
 const username=String(req.body.username||"").trim().toLowerCase();
 const password=String(req.body.password||"");
 const city=String(req.body.city||"Nairobi");
 if(!/^[a-z0-9_]{3,18}$/.test(username))return res.status(400).json({error:"Username must be 3-18 letters, numbers or _."});
 if(password.length<6)return res.status(400).json({error:"Password must be at least 6 characters."});
 try{
  const hash=bcrypt.hashSync(password,10);
  const info=db.prepare("INSERT INTO users(username,password_hash,city) VALUES(?,?,?)").run(username,hash,city);
  req.session.userId=info.lastInsertRowid;
  event(info.lastInsertRowid,"🇰🇪 Welcome to Kenya Life!");
  res.json({user:safe(user(req))});
 }catch(e){res.status(409).json({error:"That username is already taken."})}
});
app.post("/api/login",(req,res)=>{
 const u=db.prepare("SELECT * FROM users WHERE username=?").get(String(req.body.username||"").trim().toLowerCase());
 if(!u||!bcrypt.compareSync(String(req.body.password||""),u.password_hash))return res.status(401).json({error:"Wrong username or password."});
 req.session.userId=u.id; res.json({user:safe(u)});
});
app.post("/api/logout",(req,res)=>req.session.destroy(()=>res.json({ok:true})));
app.get("/api/me",auth,(req,res)=>res.json({user:safe(user(req)),events:db.prepare("SELECT message,created_at FROM events WHERE user_id=? ORDER BY id DESC LIMIT 15").all(req.user.id)}));
app.get("/api/leaderboard",(req,res)=>res.json(leaderboard()));

app.post("/api/action",auth,(req,res)=>{
 let u=user(req), action=req.body.action, msg="", delta=0, xp=0, energy=u.energy;
 if(action==="work"){
  if(energy<25)return res.status(400).json({error:"You are tired. Rest first."});
  const jobs=[["casual worker",350],["shop assistant",500],["content creator",700],["software freelancer",1200]];
  const [job,pay]=jobs[(u.level-1)%jobs.length];
  delta=pay; xp=25; energy-=25; msg=`💼 You worked as a ${job}. +KSh ${pay.toLocaleString()}`;
 } else if(action==="rest"){
  energy=Math.min(100,energy+45); msg="🛌 You rested and recovered."; xp=5;
 } else if(action==="food"){
  if(u.money<150)return res.status(400).json({error:"You need KSh 150 for food."});
  delta=-150; energy=Math.min(100,energy+15); msg="🍛 You bought food. Energy +15.";
 } else if(action==="matatu"){
  if(u.money<80)return res.status(400).json({error:"You need KSh 80 for the matatu."});
  delta=-80; energy=Math.max(0,energy-5); msg="🚌 Matatu ride: KSh 80.";
 } else if(action==="business"){
  if(u.business)return res.status(400).json({error:"You already own a starter business."});
  const cost=1500, profit=550;
  if(u.money<cost)return res.status(400).json({error:"You need KSh 1,500 to start a starter biashara."});
  delta=profit-cost; xp=60; msg="🏪 You opened a mitumba stall and made KSh 550 today.";
  db.prepare("UPDATE users SET business='Mitumba Stall',assets=assets+? WHERE id=?").run(cost,u.id);
 } else if(action==="home"){
  const cost=5000*u.home_level;
  if(u.money<cost)return res.status(400).json({error:`You need KSh ${cost.toLocaleString()} for this home upgrade.`});
  delta=-cost; xp=40; msg=`🏡 Home upgraded to level ${u.home_level+1}.`;
  db.prepare("UPDATE users SET home_level=home_level+1,assets=assets+? WHERE id=?").run(cost,u.id);
 } else if(action==="random"){
  const choices=[["🎉 A customer referred you to a friend.",800],["📱 Your post went viral.",1200],["🛠️ An unexpected repair bill arrived.",-650],["💸 You found KSh 300 in an old pocket.",300],["🤝 A friend connected you to a gig.",900]];
  const c=choices[Math.floor(Math.random()*choices.length)]; delta=c[1]; xp=20; msg=`${c[0]} ${c[1]>=0?"+":""}KSh ${Math.abs(c[1]).toLocaleString()}`;
 } else return res.status(400).json({error:"Unknown action."});

 const newMoney=Math.max(0,u.money+delta);
 const newXp=u.xp+xp;
 db.prepare("UPDATE users SET money=?,energy=?,xp=? WHERE id=?").run(newMoney,energy,newXp,u.id);
 refreshLevel(user({session:{userId:u.id}}));
 event(u.id,msg);
 const updated=user(req);
 res.json({user:safe(updated),message:msg,events:db.prepare("SELECT message,created_at FROM events WHERE user_id=? ORDER BY id DESC LIMIT 15").all(u.id)});
 broadcast();
});

io.on("connection",socket=>{
 socket.emit("leaderboard",leaderboard());
});
app.get("*",(req,res)=>res.sendFile(path.join(__dirname,"public","index.html")));
server.listen(process.env.PORT||3000,()=>console.log("Kenya Life running on port "+(process.env.PORT||3000)));